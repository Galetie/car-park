## main
* track and show available bays. x/y
* store license plates
* work in uncontrolled

## displays
* Temp
* Announcements
* update on enter and exit

